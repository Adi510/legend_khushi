LEGEN_KHUSHI 𝗜𝗦 𝗔 𝗣𝗼𝘄𝗲𝗿𝗳𝘂𝗹 𝗠𝘂𝘀𝗶𝗰 𝗯𝗼𝘁 𝗳𝗼𝗿 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 𝗚𝗿𝗼𝘂𝗽 𝗮𝗻𝗱 𝗖𝗵𝗮𝗻𝗻𝗲𝗹....

<p align="center"><a href="https://t.me/mysterious_lav"><img src="https://te.legra.ph/file/09e93cc1d04858ed1897e.jpg"></a></p>

##  𝗗𝗲𝗽𝗹𝗼𝘆 𝘁𝗼 𝗛𝗲𝗿𝗼𝗸𝘂 

- First give start then
- Fork the repo then 
- Tap below botton ☟︎︎︎☟︎︎︎☟︎︎︎ for deploy Red-Wine

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://github.com/Adi510521/legend_khushi)



### 𝗦𝘂𝗽𝗽𝗼𝗿𝘁
<a href="https://t.me/DDP_LOG"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-blue.svg?logo=Telegram"></a>
<a href="https://t.me/DDP_LOG"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>
<a href="https://youtube.com/@noyoutubechannel"><img src="https://img.shields.io/badge/Subscribe-YouTube%20Channel-red.svg?logo=YouTube"></a>
<a href="https://Instagram.com/shyamu100100"><img src="https://img.shields.io/badge/Follow-On%20Instagram-red.svg?logo=Instagram"></a>



